# Initializing parameters
##############################################################################

# Packages for ML

#install.packages("kknn")
library(kknn)
library(e1071)
library(kernlab)

# Package for R compiling

library(compiler)
enableJIT(3)

# Selected data set

data=dataNet # Change it inside loop too

# Folds for the selected data set

folds=foldsNet

# Inputs

inputs=list(c("Qtn","Fr_p"))

# Outputs

outputs=c("SBTn")

# Weighting function for KNN

mode="rectangular"

# Kernel function for SVM

#svmMode="rbfdot"
#svmMode="polydot"
svmMode="laplacedot"

# Initializing matrix with "k" values obtained for each testing case and its accucary associated

kval=matrix(0,10,1)
colnames(kval)=c("accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(kval)=rn

# Initializing list with kval matrices

lokval=list()

# Initializing list with kval mean

lokvalm=list()

# Initializing list with kval standard deviation

lokvalsd=list()

# Initializing list of models

lomodels=list()

# Initializing list of kernel parameters

lokpar=list()

# Initializing list of mean kernel parameters

lokparm=list()

# SVM application - Biased combination of 1991
##############################################################################

# For each output

for(out in outputs){
  
  # For each inputs set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Testing case
      
      cat("\nTesting case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization by rescaling
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          t=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
          mtrain[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mvalid)){
          t=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
          mvalid[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mtest)){
          t=(mtest[obj,inp[j]]-mini)/(maxi-mini)
          mtest[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")

      filt=0

      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)

        pred=fitTrain$fitted.values

        filt=filt+1

        # Remove object if it was misclassified

        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # # Normalization of unbalanced training set
      # 
      # cat("\nUnbalanced training set normalization\n\n")
      # 
      # minVal=c()
      # 
      # for(j in 1:length(inp)){
      #   minVal=cbind(minVal,min(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with minimum values
      # 
      # minVal=as.matrix(minVal)
      # colnames(minVal)=inp
      # 
      # maxVal=c()
      # 
      # for(j in 1:length(inp)){
      #   maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with maximum values
      # 
      # maxVal=as.matrix(maxVal)
      # colnames(maxVal)=inp
      # 
      # # Normalizing
      # 
      # for(j in 1:length(inp)){
      #   
      #   mini=minVal[j]
      #   maxi=maxVal[j]
      #   
      #   cat("Normalizing",inp[j],"\n")
      #   
      #   for(obj in 1:nrow(mtrain)){
      #     mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mvalid)){
      #     mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mtest)){
      #     mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      # }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of unbalanced training data set
      
      train=as.data.frame(mtrain)
      
      # Data frame of the data sets for balanced training set
      
      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])
      
      # # Pre-testing the balanced set
      # 
      # # Constructing the model
      # 
      # model = svm(formula=form,scale=T,data=trainb)
      # 
      # # Predictions
      # 
      # preds=predict(model,validb[,colnames(validb)!=out])
      # 
      # # Calculating accuracy (mean recall)
      # 
      # confb=table(preds,validb[,out])
      # 
      # mpb=0
      # 
      # for(j in colnames(confb)){
      #   if(sum(confb[,j])!=0){
      #     mpb=mpb+confb[j,j]/sum(confb[,j])
      #   }
      # }
      # 
      # mpb=mpb/ncol(confb)
      # 
      # cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      # 
      # # Pre-testing the unbalanced set
      # 
      # # Constructing the model
      # 
      # model = svm(formula=form,scale=T,data=train)
      # 
      # # Predictions
      # 
      # preds=predict(model,valid[,colnames(valid)!=out])
      # 
      # # Calculating accuracy (mean recall)
      # 
      # conf=table(preds,valid[,out])
      # 
      # mp=0
      # 
      # for(j in colnames(conf)){
      #   if(sum(conf[,j])!=0){
      #     mp=mp+conf[j,j]/sum(conf[,j])
      #   }
      # }
      # 
      # mp=mp/ncol(conf)
      # 
      # cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      # 
      # if(mpb>mp){
      #   train=trainb
      #   test=testb
      #   valid=validb
      #   cat("Using balanced set!\n\n")
      # }
      # else{
      #   cat("Using unbalanced set!\n\n")
      # }
      
      if(svmMode=="polydot"){
        cat("\nTraining\n\n")
        
        deg=1
        
        scl=1
        
        prevmp1=0
        
        prevoffs=1
        
        cont1=1
        
        while(cont1){
          
          cont2=1
          
          offs=1
          
          prevmp2=0
          
          while(cont2){
            
            # Constructing the model
            
            model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=list(degree=deg,scale=scl,offset=offs))
            
            # Predictions
            
            preds=predict(model,validb[,colnames(validb)!=out])
            
            # Calculating accuracy (mean recall)
            
            conf=table(preds,validb[,out])
            
            mp=0
            
            for(j in colnames(conf)){
              if(sum(conf[,j])!=0){
                mp=mp+conf[j,j]/sum(conf[,j])
              }
            }
            
            mp=mp/ncol(conf)
            
            cat("Accuracy with degree =",deg,"scale =",scl,"and offset =",offs,":",mp*100,"%\n\n")
            
            if(mp>prevmp2){
              offs=offs+1
              prevmp2=mp
            }else{
              offs=offs-1
              cont2=0
            }
          }
          
          if(prevmp2>prevmp1){
            deg=deg+1
            prevmp1=prevmp2
            prevoffs=offs
          }else{
            deg=deg-1
            offs=prevoffs
            cont1=0
          }
        }
        
        cont1=1
        
        scl=2
        
        while(cont1){
          
          # Constructing the model
          
          model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=list(degree=deg,scale=scl,offset=offs))
          
          # Predictions
          
          preds=predict(model,validb[,colnames(validb)!=out])
          
          # Calculating accuracy (mean recall)
          
          conf=table(preds,validb[,out])
          
          mp=0
          
          for(j in colnames(conf)){
            if(sum(conf[,j])!=0){
              mp=mp+conf[j,j]/sum(conf[,j])
            }
          }
          
          mp=mp/ncol(conf)
          
          cat("Accuracy with degree =",deg,"scale =",scl,"and offset =",offs,":",mp*100,"%\n\n")
          
          if(mp>prevmp1){
            scl=scl+1
            prevmp1=mp
          }else{
            scl=scl-1
            cont1=0
          }
        }
        kparam=list(deg,scl,offs)
        lokpar[[length(lokpar)+1]]=c(deg,scl,offs)
      }else{
        kparam="automatic"
      }
      
      cat("\nTesting\n\n")
      
      # Testing
      
      # Constructing the model
      
      model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=kparam)
      
      # Predictions
      
      preds=predict(model,testb[,colnames(testb)!=out])
      
      # Calculating accuracy (mean recall)
      
      conf=table(preds,testb[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        if(sum(conf[,j])!=0){
          mp=mp+conf[j,j]/sum(conf[,j])
        }
      }
      
      mp=mp/ncol(conf)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping accuracy
      
      kval[i,1]=mp*100
      
      # Keeping model
      
      lomodels[[length(lomodels)+1]]=model
    }
    
    # Determining kparam
    
    if(svmMode=="polydot"){
      kparam=list(0,0,0)
      for(j in (length(lokpar)-9):length(lokpar)){
        kparam[[1]]=kparam[[1]]+lokpar[[j]][1]
        kparam[[2]]=kparam[[2]]+lokpar[[j]][2]
        kparam[[3]]=kparam[[3]]+lokpar[[j]][3]
      }
      kparam[[1]]=round(kparam[[1]]/10)
      kparam[[2]]=round(kparam[[2]]/10)
      kparam[[3]]=round(kparam[[3]]/10)
      
      lokparm[[length(lokparm)+1]]=c(kparam[[1]],kparam[[2]],kparam[[3]])
    }else{
      kparam="automatic"
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,1])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,1])
    
    # Converting data into matrix
    
    mdata=as.matrix(data)
    
    # Removing Robertson's (1991) class 0
    
    if(out=="SBTn"){
      mdata=mdata[mdata[,out]!=0,]
    }
    
    # Normalization by rescaling
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdata[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdata[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdata)){
        t=(mdata[obj,inp[j]]-mini)/(maxi-mini)
        mdata[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
      }
    }
    
    # Statistical marks for pre-filtering
    
    q1=c()
    q3=c()
    
    for(class in sort(unique(mdata[,out]))){
      auxq1=c()
      auxq3=c()
      for(at in inp[inp!="Depth_m"]){
        
        # First quartile
        
        auxq1=append(auxq1,quantile(mdata[mdata[,out]==class,at])[2])
        
        # Third quartile
        
        auxq3=append(auxq3,quantile(mdata[mdata[,out]==class,at])[4])
        
      }
      q1=cbind(q1,auxq1)
      q3=cbind(q3,auxq3)
    }
    
    
    # Interquartil interval
    
    iq=q3-q1
    
    # Formating
    
    q1=t(as.matrix(q1))
    colnames(q1)=inp[inp!="Depth_m"]
    rownames(q1)=sort(unique(mdata[,out]))
    
    q3=t(as.matrix(q3))
    colnames(q3)=inp[inp!="Depth_m"]
    rownames(q3)=sort(unique(mdata[,out]))
    
    iq=t(as.matrix(iq))
    colnames(iq)=inp[inp!="Depth_m"]
    rownames(iq)=sort(unique(mdata[,out]))
    
    # Data cleaning
    
    removed=0
    idx=c()
    
    # Pre-filtering
    
    cat("\nPre-filtering\n")
    
    for(obj in 1:nrow(mdata)){
      class=as.character(mdata[obj,out])
      for(at in inp[inp!="Depth_m"]){
        if(mdata[obj,at]>q3[class,at]+1.5*iq[class,at]
           || mdata[obj,at]<q1[class,at]-1.5*iq[class,at]){
          if(length(idx)==0 || obj!=idx[length(idx)]){
            idx=append(idx,obj)
            #cat("Pre-filtered:",length(idx),"\n")
            #cat("Object:",obj,"\n\n")
          }
        }
      }
    }
    
    # Data frame of the data set
    
    data=as.data.frame(mdata)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    # Filtering
    
    cat("\nFiltering\n")
    
    filt=0
    
    for(obj in 1:length(idx)){
      fitTrain <- kknn(formula=form,
                       train=data[-idx[obj],],
                       test=data[idx[obj],],
                       k=1,
                       distance=2,
                       kernel=mode,
                       scale=FALSE)
      
      pred=fitTrain$fitted.values
      
      filt=filt+1
      
      # Remove object if it was misclassified
      
      if(pred!=data[idx[obj],out]){
        train=data[-idx[obj],]
        idx=idx-1
        removed=removed+1
        #cat("Filtered:",removed,"\n\n")
        #cat("Pre-filtered object:",filt,"\n")
      }
    }
    
    # Training data set as matrix
    
    data[,out]=as.numeric(as.character(data[,out]))
    mdata=as.matrix(data)
    
    # Initializing sets for balanced training set
    
    mdatab=mdata
    
    # Proportion check
    
    cat("\nProportion check\n\n")
    
    prop=c()
    
    for(j in sort(unique(mdatab[,out]))){
      prop=append(prop,nrow(mdatab[mdatab[,out]==j,]))
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    cat("\nBalancing\n\n")
    
    # Number of elements in the minority class
    
    minProp=min(prop)
    
    # Total number of elements by class
    
    nTot=max(1000,2*minProp)
    
    # Balancing
    
    for(j in sort(unique(mdatab[,out]))){
      mtrainClass=mdatab[mdatab[,out]==j,]
      numEl=nrow(mtrainClass)
      if(numEl>nTot){
        set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
        objIdx=sample(nrow(mtrainClass),numEl-nTot)
        mdatab=rbind(mdatab[mdatab[,out]!=j,],mtrainClass[-objIdx,])
      }
      else if(numEl<nTot){
        for(p in 1:(nTot-numEl)){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),length(inp)+1)
          obj=c()
          for(at in colnames(mdatab)){
            if(at==out){
              obj=append(obj,j)
            }else{
              obj=append(obj,mean(mtrainClass[objIdx,at]))
            }
          }
          mdatab=rbind(mdatab,obj)
        }
      }
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    # Normalization of balanced training set
    
    cat("\nBalanced training set normalization\n\n")
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdatab[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdatab[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdatab)){
        mdatab[obj,inp[j]]=(mdatab[obj,inp[j]]-mini)/(maxi-mini)
      }
    }
    
    # Data frame of test data set
    
    data=as.data.frame(mdata)
    
    # Data frame of the data sets for balanced training set
    
    datab=as.data.frame(mdatab)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    datab[,out]=as.factor(datab[,out])
    
    cat("\nTesting\n\n")
    
    # Constructing a general model
    
    model=ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=datab,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=kparam)
    
    # Keeping model
    
    lomodels[[length(lomodels)+1]]=model
  }
}

# Initializing parameters
##############################################################################

# Inputs

inputs=list(c("Qtn","Fr_p","U2"))

# Outputs

outputs=c("MSBTn")

# SVM application - Biased combination of 2016
##############################################################################

# For each output

for(out in outputs){
  
  # For each inputs set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Testing case
      
      cat("\nTesting case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization by rescaling
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          t=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
          mtrain[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mvalid)){
          t=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
          mvalid[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mtest)){
          t=(mtest[obj,inp[j]]-mini)/(maxi-mini)
          mtest[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")
      
      filt=0
      
      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        pred=fitTrain$fitted.values
        
        filt=filt+1
        
        # Remove object if it was misclassified
        
        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # # Normalization of unbalanced training set
      # 
      # cat("\nUnbalanced training set normalization\n\n")
      # 
      # minVal=c()
      # 
      # for(j in 1:length(inp)){
      #   minVal=cbind(minVal,min(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with minimum values
      # 
      # minVal=as.matrix(minVal)
      # colnames(minVal)=inp
      # 
      # maxVal=c()
      # 
      # for(j in 1:length(inp)){
      #   maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with maximum values
      # 
      # maxVal=as.matrix(maxVal)
      # colnames(maxVal)=inp
      # 
      # # Normalizing
      # 
      # for(j in 1:length(inp)){
      #   
      #   mini=minVal[j]
      #   maxi=maxVal[j]
      #   
      #   cat("Normalizing",inp[j],"\n")
      #   
      #   for(obj in 1:nrow(mtrain)){
      #     mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mvalid)){
      #     mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mtest)){
      #     mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      # }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of unbalanced training data set
      
      train=as.data.frame(mtrain)
      
      # Data frame of the data sets for balanced training set
      
      testb=as.data.frame(mtestb)
      validb=as.data.frame(mvalidb)
      trainb=as.data.frame(mtrainb)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      trainb[,out]=as.factor(trainb[,out])
      validb[,out]=as.factor(validb[,out])
      testb[,out]=as.factor(testb[,out])
      
      # # Pre-testing the balanced set
      # 
      # # Constructing the model
      # 
      # model = svm(formula=form,scale=T,data=trainb)
      # 
      # # Predictions
      # 
      # preds=predict(model,validb[,colnames(validb)!=out])
      # 
      # # Calculating accuracy (mean recall)
      # 
      # confb=table(preds,validb[,out])
      # 
      # mpb=0
      # 
      # for(j in colnames(confb)){
      #   if(sum(confb[,j])!=0){
      #     mpb=mpb+confb[j,j]/sum(confb[,j])
      #   }
      # }
      # 
      # mpb=mpb/ncol(confb)
      # 
      # cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      # 
      # # Pre-testing the unbalanced set
      # 
      # # Constructing the model
      # 
      # model = svm(formula=form,scale=T,data=train)
      # 
      # # Predictions
      # 
      # preds=predict(model,valid[,colnames(valid)!=out])
      # 
      # # Calculating accuracy (mean recall)
      # 
      # conf=table(preds,valid[,out])
      # 
      # mp=0
      # 
      # for(j in colnames(conf)){
      #   if(sum(conf[,j])!=0){
      #     mp=mp+conf[j,j]/sum(conf[,j])
      #   }
      # }
      # 
      # mp=mp/ncol(conf)
      # 
      # cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      # 
      # if(mpb>mp){
      #   train=trainb
      #   test=testb
      #   valid=validb
      #   cat("Using balanced set!\n\n")
      # }
      # else{
      #   cat("Using unbalanced set!\n\n")
      # }
      
      if(svmMode=="polydot"){
        cat("\nTraining\n\n")
        
        deg=1
        
        scl=1
        
        prevmp1=0
        
        prevoffs=1
        
        cont1=1
        
        while(cont1){
          
          cont2=1
          
          offs=1
          
          prevmp2=0
          
          while(cont2){
            
            # Constructing the model
            
            model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=list(degree=deg,scale=scl,offset=offs))
            
            # Predictions
            
            preds=predict(model,validb[,colnames(validb)!=out])
            
            # Calculating accuracy (mean recall)
            
            conf=table(preds,validb[,out])
            
            mp=0
            
            for(j in colnames(conf)){
              if(sum(conf[,j])!=0){
                mp=mp+conf[j,j]/sum(conf[,j])
              }
            }
            
            mp=mp/ncol(conf)
            
            cat("Accuracy with degree =",deg,"scale =",scl,"and offset =",offs,":",mp*100,"%\n\n")
            
            if(mp>prevmp2){
              offs=offs+1
              prevmp2=mp
            }else{
              offs=offs-1
              cont2=0
            }
          }
          
          if(prevmp2>prevmp1){
            deg=deg+1
            prevmp1=prevmp2
            prevoffs=offs
          }else{
            deg=deg-1
            offs=prevoffs
            cont1=0
          }
        }
        
        cont1=1
        
        scl=2
        
        while(cont1){
          
          # Constructing the model
          
          model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=list(degree=deg,scale=scl,offset=offs))
          
          # Predictions
          
          preds=predict(model,validb[,colnames(validb)!=out])
          
          # Calculating accuracy (mean recall)
          
          conf=table(preds,validb[,out])
          
          mp=0
          
          for(j in colnames(conf)){
            if(sum(conf[,j])!=0){
              mp=mp+conf[j,j]/sum(conf[,j])
            }
          }
          
          mp=mp/ncol(conf)
          
          cat("Accuracy with degree =",deg,"scale =",scl,"and offset =",offs,":",mp*100,"%\n\n")
          
          if(mp>prevmp1){
            scl=scl+1
            prevmp1=mp
          }else{
            scl=scl-1
            cont1=0
          }
        }
        kparam=list(deg,scl,offs)
        lokpar[[length(lokpar)+1]]=c(deg,scl,offs)
      }else{
        kparam="automatic"
      }
      
      cat("\nTesting\n\n")
      
      # Testing
      
      # Constructing the model
      
      model = ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=trainb,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=kparam)
      
      # Predictions
      
      preds=predict(model,testb[,colnames(testb)!=out])
      
      # Calculating accuracy (mean recall)
      
      conf=table(preds,testb[,out])
      
      mp=0
      
      for(j in colnames(conf)){
        if(sum(conf[,j])!=0){
          mp=mp+conf[j,j]/sum(conf[,j])
        }
      }
      
      mp=mp/ncol(conf)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping accuracy
      
      kval[i,1]=mp*100
      
      # Keeping model
      
      lomodels[[length(lomodels)+1]]=model
    }
    
    # Determining kparam
    
    if(svmMode=="polydot"){
      kparam=list(0,0,0)
      for(j in (length(lokpar)-9):length(lokpar)){
        kparam[[1]]=kparam[[1]]+lokpar[[j]][1]
        kparam[[2]]=kparam[[2]]+lokpar[[j]][2]
        kparam[[3]]=kparam[[3]]+lokpar[[j]][3]
      }
      kparam[[1]]=round(kparam[[1]]/10)
      kparam[[2]]=round(kparam[[2]]/10)
      kparam[[3]]=round(kparam[[3]]/10)
      
      lokparm[[length(lokparm)+1]]=c(kparam[[1]],kparam[[2]],kparam[[3]])
    }else{
      kparam="automatic"
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,1])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,1])
    
    # Converting data into matrix
    
    mdata=as.matrix(data)
    
    # Removing Robertson's (1991) class 0
    
    if(out=="SBTn"){
      mdata=mdata[mdata[,out]!=0,]
    }
    
    # Normalization by rescaling
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdata[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdata[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdata)){
        t=(mdata[obj,inp[j]]-mini)/(maxi-mini)
        mdata[obj,inp[j]]=sign(t)*log10(1+(10^2-1)*abs(t))/2
      }
    }
    
    # Statistical marks for pre-filtering
    
    q1=c()
    q3=c()
    
    for(class in sort(unique(mdata[,out]))){
      auxq1=c()
      auxq3=c()
      for(at in inp[inp!="Depth_m"]){
        
        # First quartile
        
        auxq1=append(auxq1,quantile(mdata[mdata[,out]==class,at])[2])
        
        # Third quartile
        
        auxq3=append(auxq3,quantile(mdata[mdata[,out]==class,at])[4])
        
      }
      q1=cbind(q1,auxq1)
      q3=cbind(q3,auxq3)
    }
    
    
    # Interquartil interval
    
    iq=q3-q1
    
    # Formating
    
    q1=t(as.matrix(q1))
    colnames(q1)=inp[inp!="Depth_m"]
    rownames(q1)=sort(unique(mdata[,out]))
    
    q3=t(as.matrix(q3))
    colnames(q3)=inp[inp!="Depth_m"]
    rownames(q3)=sort(unique(mdata[,out]))
    
    iq=t(as.matrix(iq))
    colnames(iq)=inp[inp!="Depth_m"]
    rownames(iq)=sort(unique(mdata[,out]))
    
    # Data cleaning
    
    removed=0
    idx=c()
    
    # Pre-filtering
    
    cat("\nPre-filtering\n")
    
    for(obj in 1:nrow(mdata)){
      class=as.character(mdata[obj,out])
      for(at in inp[inp!="Depth_m"]){
        if(mdata[obj,at]>q3[class,at]+1.5*iq[class,at]
           || mdata[obj,at]<q1[class,at]-1.5*iq[class,at]){
          if(length(idx)==0 || obj!=idx[length(idx)]){
            idx=append(idx,obj)
            #cat("Pre-filtered:",length(idx),"\n")
            #cat("Object:",obj,"\n\n")
          }
        }
      }
    }
    
    # Data frame of the data set
    
    data=as.data.frame(mdata)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    # Filtering
    
    cat("\nFiltering\n")
    
    filt=0
    
    for(obj in 1:length(idx)){
      fitTrain <- kknn(formula=form,
                       train=data[-idx[obj],],
                       test=data[idx[obj],],
                       k=1,
                       distance=2,
                       kernel=mode,
                       scale=FALSE)
      
      pred=fitTrain$fitted.values
      
      filt=filt+1
      
      # Remove object if it was misclassified
      
      if(pred!=data[idx[obj],out]){
        train=data[-idx[obj],]
        idx=idx-1
        removed=removed+1
        #cat("Filtered:",removed,"\n\n")
        #cat("Pre-filtered object:",filt,"\n")
      }
    }
    
    # Training data set as matrix
    
    data[,out]=as.numeric(as.character(data[,out]))
    mdata=as.matrix(data)
    
    # Initializing sets for balanced training set
    
    mdatab=mdata
    
    # Proportion check
    
    cat("\nProportion check\n\n")
    
    prop=c()
    
    for(j in sort(unique(mdatab[,out]))){
      prop=append(prop,nrow(mdatab[mdatab[,out]==j,]))
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    cat("\nBalancing\n\n")
    
    # Number of elements in the minority class
    
    minProp=min(prop)
    
    # Total number of elements by class
    
    nTot=max(1000,2*minProp)
    
    # Balancing
    
    for(j in sort(unique(mdatab[,out]))){
      mtrainClass=mdatab[mdatab[,out]==j,]
      numEl=nrow(mtrainClass)
      if(numEl>nTot){
        set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
        objIdx=sample(nrow(mtrainClass),numEl-nTot)
        mdatab=rbind(mdatab[mdatab[,out]!=j,],mtrainClass[-objIdx,])
      }
      else if(numEl<nTot){
        for(p in 1:(nTot-numEl)){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),length(inp)+1)
          obj=c()
          for(at in colnames(mdatab)){
            if(at==out){
              obj=append(obj,j)
            }else{
              obj=append(obj,mean(mtrainClass[objIdx,at]))
            }
          }
          mdatab=rbind(mdatab,obj)
        }
      }
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    # Normalization of balanced training set
    
    cat("\nBalanced training set normalization\n\n")
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdatab[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdatab[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdatab)){
        mdatab[obj,inp[j]]=(mdatab[obj,inp[j]]-mini)/(maxi-mini)
      }
    }
    
    # Data frame of test data set
    
    data=as.data.frame(mdata)
    
    # Data frame of the data sets for balanced training set
    
    datab=as.data.frame(mdatab)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    datab[,out]=as.factor(datab[,out])
    
    cat("\nTesting\n\n")
    
    # Constructing a general model
    
    model=ksvm(x=form,scaled=as.vector(matrix(F,length(inp),1)),data=datab,type="C-svc",kernel=svmMode,tol=1e-3,shrinking=T,fit=T,kpar=kparam)
    
    # Keeping model
    
    lomodels[[length(lomodels)+1]]=model
  }
}

