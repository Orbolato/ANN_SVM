% Predicao da vazao de rios com metodologia NARMAX
clear all
clc
% Fase 1: Obter os padroes de treinamento

camargos=load('Camargos.txt'); % Rio 1, Camargos
furnas=load('Furnas.txt'); % Rio 2, Furnas
Po=[];
To=[];
for i=1:1:(82*12-2)
    inp=[camargos(floor((i-1)/12)+1,mod((i-1),12)+1), ...
        camargos(floor(i/12)+1,mod(i,12)+1), ...
        furnas(floor((i-1)/12)+1,mod(i-1,12)+1), ... 
        furnas(floor(i/12)+1,mod(i,12)+1)];
    Po=[Po;inp];
    out=[camargos(floor((i+1)/12)+1,mod(i+1,12)+1), ... 
        furnas(floor((i+1)/12)+1,mod(i+1,12)+1)];
    To=[To;out];
end
P=Po(1:81*12-2,:)';
T=To(1:81*12-2,:)';

% Fase 2: Criar arquitetura de rede MLP

%nnet=feedforwardnet(20); % Modelo 1
nnet=feedforwardnet([20,30,25]); % Modelo 2
%nnet=feedforwardnet(190); % Modelo 3
%nnet=feedforwardnet(110); % Modelo 4
%nnet=feedforwardnet(155); % Modelo 5
%nnet=feedforwardnet([95,95]); % Modelo 6
nnet=configure(nnet,P,T);

% Fase 3: Dividir padroes entre treinamento, 
% teste e validacao

nnet.divideFcn='dividerand';
nnet.divideParam.trainRatio=1.00;
nnet.divideParam.valRatio=0.00;
nnet.divideParam.testRatio=0.00;

% Fase 4: Inicializacao dos pesos da rede

nnet=init(nnet);

% Fase 5: Treinamento da rede

nnet.trainParam.showWindow=true; % Exibicao grafica
%nnet.layers{1}.dimensions=20; % 1a camada oculta
nnet.layers{1}.dimensions=20; % 1a camada oculta
%nnet.layers{1}.dimensions=190; % 1a camada oculta
%nnet.layers{1}.dimensions=110; % 1a camada oculta
%nnet.layers{1}.dimensions=155; % 1a camada oculta
%nnet.layers{1}.dimensions=95; % 1a camada oculta
nnet.layers{1}.transferFcn='tansig'; % Fcao de ativacao
nnet.layers{2}.dimensions=30; % 2a camada oculta
%nnet.layers{2}.dimensions=95; % 2a camada oculta
nnet.layers{2}.transferFcn='tansig'; % Fcao de ativacao
nnet.layers{3}.dimensions=25; % 3a camada oculta
nnet.layers{3}.transferFcn='tansig'; % Fcao de ativacao
nnet.layers{4}.transferFcn='purelin'; % Fcao de ativacao
nnet.performFcn='mse'; % Medida de desempenho
%nnet.performParam.normalization = 'none';
nnet.trainFcn='trainlm'; % Levenberg-Marquard
%nnet.trainFcn='trainrp'; % Resilient Back-propagation
%nnet.trainFcn='traincgp'; % Conjugate Gradient
%nnet.trainFcn='trainbr'; % Bayesian Regulatization
%nnet.trainFcn='trainrp'; % Resilient Back-propagation
nnet.trainParam.epochs=10^4; % Maximo de epocas
nnet.trainParam.time=120; % Tempo maximo(segundos)
nnet.trainParam.lr=0.2; % Taxa de aprendizado
nnet.trainParam.min_grad=10^-8; % Gradiente de parada
[nnet,tr]=train(nnet,P,T); % Treinamento

% Fase 6.1: Simulacao das saidas - Rio Camargos
% Fase 6.1.1: Plotar os padroes de treinamento

xP=(81*12+1):1:(82*12);
yP=To;
plot(xP,yP((81*12-1):1:(82*12-2),1),'b')
xlabel('Meses')
ylabel('Vazao')
title('Vazao do Rio Camargos')
grid
hold on

% Fase 6.1.2: Plotar resultados da simulacao

xS=(81*12+1):1:(82*12);
yS=nnet(Po');
plot(xS,yS(1,(81*12-1):1:(82*12-2)),':m');
figure

% Fase 6.2: Simulacao das saidas - Rio Furnas
% Fase 6.2.1: Plotar os padroes de treinamento

xP=(81*12+1):1:(82*12);
yP=To;
plot(xP,yP((81*12-1):1:(82*12-2),2),'r')
xlabel('Meses')
ylabel('Vazao')
title('Vazao do Rio Furnas')
grid
hold on

% Fase 6.2.2: Plotar resultados da simulacao

xS=(81*12+1):1:(82*12);
yS=nnet(Po');
plot(xS,yS(2,(81*12-1):1:(82*12-2)),':m');