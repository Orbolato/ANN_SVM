# Initializing parameters
##############################################################################

# Packages for ML techniques

library(kknn)
library(RSNNS)

# Package for R compiling

library(compiler)
enableJIT(3)

# Selected data set

data=dataNet # Change it inside loop too

# Folds for the selected data set

folds=foldsNet

# Input features set

inputs=list(c("Qtn","Fr_p"))

# Outputs

outputs=c("SBTn")

# Initializing matrix with "k" values obtained for each testing case and its accuracy associated

kval=matrix(0,10,4)
colnames(kval)=c("n","m","iterations","accuracy")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(kval)=rn

# Initializing list with kval matrices

lokval=list()

# Initializing list with kval mean

lokvalm=list()

# Initializing list with kval standard deviation

lokvalsd=list()

# Initializing list of best "n" values

lon=list()

# Initializing list of best "m" values

lom=list()

# Initializing list of weight matrix

lowm=list()

# k-NN mode for filtering

mode="rectangular"

# ANN application - Biased combination of 1991
##############################################################################

# For each output set

for(out in outputs){
  # For each input set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Defining formula
      
      form=paste(inp,collapse="+")
      form=as.formula(paste(append(out,form),collapse="~"))
      
      # Testing case
      
      cat("Testing case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          t=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
          mtrain[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mvalid)){
          t=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
          mvalid[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mtest)){
          t=(mtest[obj,inp[j]]-mini)/(maxi-mini)
          mtest[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")

      filt=0

      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)

        pred=fitTrain$fitted.values

        filt=filt+1

        # Remove object if it was misclassified

        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          mtrain=mtrain[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # Modifying with one-to-c (canonic) encoding
      
      classZero=min(unique(mtrain[,out]))
      nclass=max(unique(mtrain[,out]))
      iniCols=ncol(mtrain)
      for(j in classZero:nclass){
        mtrain=cbind(mtrain,matrix(0,nrow(mtrain),1))
        colnames(mtrain)[length(colnames(mtrain))]=paste("c",as.character(j),sep="")
        mvalid=cbind(mvalid,matrix(0,nrow(mvalid),1))
        colnames(mvalid)[length(colnames(mvalid))]=paste("c",as.character(j),sep="")
        mtest=cbind(mtest,matrix(0,nrow(mtest),1))
        colnames(mtest)[length(colnames(mtest))]=paste("c",as.character(j),sep="")
        mtrainb=cbind(mtrainb,matrix(0,nrow(mtrainb),1))
        colnames(mtrainb)[length(colnames(mtrainb))]=paste("c",as.character(j),sep="")
        mvalidb=cbind(mvalidb,matrix(0,nrow(mvalidb),1))
        colnames(mvalidb)[length(colnames(mvalidb))]=paste("c",as.character(j),sep="")
        mtestb=cbind(mtestb,matrix(0,nrow(mtestb),1))
        colnames(mtestb)[length(colnames(mtestb))]=paste("c",as.character(j),sep="")
      }
      for(j in 1:nrow(mtrain)){
        mtrain[j,iniCols+mtrain[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtest)){
        mtest[j,iniCols+mtest[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mvalid)){
        mvalid[j,iniCols+mvalid[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtrainb)){
        mtrainb[j,iniCols+mtrainb[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtestb)){
        mtestb[j,iniCols+mtestb[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mvalidb)){
        mvalidb[j,iniCols+mvalidb[j,out]+1-classZero]=1
      }
      mtrain=mtrain[,colnames(mtrain)!=out]
      mtest=mtest[,colnames(mtest)!=out]
      mvalid=mvalid[,colnames(mvalid)!=out]
      mtrainb=mtrainb[,colnames(mtrainb)!=out]
      mtestb=mtestb[,colnames(mtestb)!=out]
      mvalidb=mvalidb[,colnames(mvalidb)!=out]
      iniCols=iniCols-1
      
      # # Normalization of unbalanced training set
      # 
      # cat("\nUnbalanced training set normalization\n\n")
      # 
      # minVal=c()
      # 
      # for(j in 1:length(inp)){
      #   minVal=cbind(minVal,min(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with minimum values
      # 
      # minVal=as.matrix(minVal)
      # colnames(minVal)=inp
      # 
      # maxVal=c()
      # 
      # for(j in 1:length(inp)){
      #   maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with maximum values
      # 
      # maxVal=as.matrix(maxVal)
      # colnames(maxVal)=inp
      # 
      # # Normalizing
      # 
      # for(j in 1:length(inp)){
      #   
      #   mini=minVal[j]
      #   maxi=maxVal[j]
      #   
      #   cat("Normalizing",inp[j],"\n")
      #   
      #   for(obj in 1:nrow(mtrain)){
      #     mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mvalid)){
      #     mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mtest)){
      #     mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      # }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      # New formula
      
      fout=colnames(mtrain)[iniCols+1]
      
      for(j in (classZero+1):nclass){
        fout=paste(fout,colnames(mtrain)[iniCols+j+1-classZero],sep="+")
      }
      
      form=paste(fout,as.character(form)[length(as.character(form))],sep="~")
      
      form=as.formula(form)
      
      # From matrix into dataframe
      
      train=as.data.frame(mtrain)
      rownames(train)=NULL
      valid=as.data.frame(mvalid)
      rownames(valid)=NULL
      test=as.data.frame(mtest)
      rownames(test)=NULL
      
      trainb=as.data.frame(mtrainb)
      rownames(trainb)=NULL
      validb=as.data.frame(mvalidb)
      rownames(validb)=NULL
      testb=as.data.frame(mtestb)
      rownames(testb)=NULL
      
      # # Pre-testing the balanced set
      # 
      # # Constructing the model
      # 
      # model = mlp(x=mtrainb[,c(1:iniCols)],y=mtrainb[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=200,outputActFunc="Act_Logistic")
      # 
      # # Predictions
      # 
      # predictions=predict(model,mvalidb[,1:iniCols])
      # preds=predictions
      # for(p in 1:nrow(preds)){
      #   for(q in 1:ncol(preds)){
      #     if(preds[p,q]==max(preds[p,])){
      #       preds[p,q]=1
      #     }else{
      #       preds[p,q]=0
      #     }
      #   }
      # }
      # 
      # # Calculating accuracy
      # 
      # mpb=0
      # 
      # for(j in classZero:nclass){
      #   mpb=mpb+sum(preds[preds[,j+1-classZero]==mvalidb[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalidb[,iniCols+j+1-classZero])
      # }
      # 
      # mpb=mpb/(nclass-classZero+1)
      # 
      # cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      # 
      # # Pre-testing the unbalanced set
      # 
      # # Constructing the model
      # 
      # model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=200,outputActFunc="Act_Logistic")
      # 
      # # Predictions
      # 
      # predictions=predict(model,mvalid[,1:iniCols])
      # preds=predictions
      # for(p in 1:nrow(preds)){
      #   for(q in 1:ncol(preds)){
      #     if(preds[p,q]==max(preds[p,])){
      #       preds[p,q]=1
      #     }else{
      #       preds[p,q]=0
      #     }
      #   }
      # }
      # 
      # # Calculating accuracy
      # 
      # mp=0
      # 
      # for(j in classZero:nclass){
      #   mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
      # }
      # 
      # mp=mp/(nclass-classZero+1)
      # 
      # cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      # 
      # if(mpb>mp){
      #   mtrain=mtrainb
      #   mtest=mtestb
      #   mvalid=mvalidb
      #   cat("Using balanced set!\n\n")
      # }
      # else{
      #   cat("Using unbalanced set!\n\n")
      # }
      
      mtrain=mtrainb
      mtest=mtestb
      mvalid=mvalidb
      cat("Using balanced set!\n\n")
      
      # Determining the maximum number of iterations
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp=0
      
      # Initializing number of neurons on the first hidden layer
      
      it=200
      
      while(cont){
        
        cat("Training with ", it," iterations\n\n")
        
        # Constructing the model
        
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=it,outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalid[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        if(mp < prevmp){
          cont=0
          it=it-200
        }else{
          it=it+200
          prevmp=mp
        }
      }
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp1=0
      
      # Initializing number of neurons on the first hidden layer
      
      n=1#nclass-classZero+1
      
      # Initializing the best number of neurons
      
      nmax=1#nclass-classZero+1
      
      # Training
      
      while(cont){
        
        cat("Training for n =",n," and m =", 0, "\n")
        
        # Constructing the model
        
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n),maxit=it,outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalid[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        # if(mp < prevmp1){
        #   cont=0
        #   n=n-1
        # }else{
        #   n=n+1
        #   prevmp1=mp
        # }
        
        if(mp > prevmp1){
          prevmp1=mp
          nmax=n
        }
        
        if(n==2*(nclass-classZero+1)){
          cont=0
        }else{
          n=n+1
        }
      }
      
      n=nmax
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean recall
      
      prevmp2=0
      
      # Initializing number of neurons on the second hidden layer
      
      m=1#nclass-classZero+1
      
      # Initializing the best number of neurons
      
      mmax=1#nclass-classZero+1
      
      # Training
      
      while(cont){
        
        cat("Training for n =",n," and m =", m, "\n")
        
        # Constructing the model
        
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n,m),maxit=it,hiddenActFunc="Act_Logistic",outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalid[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        # if(mp < prevmp2){
        #   cont=0
        #   m=m-1
        # }else{
        #   m=m+1
        #   prevmp2=mp
        # }
        
        if(mp > prevmp2){
          prevmp2=mp
          mmax=m
        }
        
        if(m==2*(nclass-classZero+1)){
          cont=0
        }else{
          m=m+1
        }
      }
      
      # Using the second hidden layer just if it improves the model
      
      if(prevmp2<=prevmp1){
        m=0
      }else{
        m=mmax
      }
      
      cat("Testing for n =",n,"and m =",m," with",it,"iterations\n")
      
      # Testing
      
      # Constructing the model
      
      if(m!=0){
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n,m),maxit=it,outputActFunc="Act_Logistic")
      }else{
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n),maxit=it,outputActFunc="Act_Logistic")
      }
      
      # Predictions
      
      predictions=predict(model,mtest[,1:iniCols])
      preds=predictions
      for(p in 1:nrow(preds)){
        for(q in 1:ncol(preds)){
          if(preds[p,q]==max(preds[p,])){
            preds[p,q]=1
          }else{
            preds[p,q]=0
          }
        }
      }
      
      # Calculating accuracy
      
      mp=0
      
      for(j in classZero:nclass){
        mp=mp+sum(preds[preds[,j+1-classZero]==mtest[,iniCols+j+1-classZero],j+1-classZero])/sum(mtest[,iniCols+j+1-classZero])
      }
      
      mp=mp/(nclass-classZero+1)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping "n" value for the ith testing case
      
      kval[i,1]=n
      
      # Keeping "m" value for the ith testing case
      
      kval[i,2]=m
      
      # Keeping number of iterations
      
      kval[i,3]=it
      
      # Keeping accuracy related to "k"
      
      kval[i,4]=mp*100
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,"accuracy"])
    
    # Best "n"
    
    x=kval[,"n"]
    z=table(as.vector(x))
    bn=as.numeric(names(z)[z == max(z)])[1]
    lon[[length(lon)+1]]=bn
    
    # Best "m"
    
    x=kval[,"m"]
    z=table(as.vector(x))
    bm=as.numeric(names(z)[z == max(z)])[1]
    lom[[length(lom)+1]]=bm
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    # Data as matrix
    
    mdata=as.matrix(data)
    
    # Removing Robertson's (1991) class 0
    
    if(out=="SBTn"){
      mdata=mdata[mdata[,out]!=0,]
    }
    
    # Normalization
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdata[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdata[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdata)){
        t=(mdata[obj,inp[j]]-mini)/(maxi-mini)
        mdata[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
      }
    }
    
    # Statistical marks for pre-filtering
    
    q1=c()
    q3=c()
    
    for(class in sort(unique(mdata[,out]))){
      auxq1=c()
      auxq3=c()
      for(at in inp[inp!="Depth_m"]){
        
        # First quartile
        
        auxq1=append(auxq1,quantile(mdata[mdata[,out]==class,at])[2])
        
        # Third quartile
        
        auxq3=append(auxq3,quantile(mdata[mdata[,out]==class,at])[4])
        
      }
      q1=cbind(q1,auxq1)
      q3=cbind(q3,auxq3)
    }
    
    
    # Interquartil interval
    
    iq=q3-q1
    
    # Formating
    
    q1=t(as.matrix(q1))
    colnames(q1)=inp[inp!="Depth_m"]
    rownames(q1)=sort(unique(mdata[,out]))
    
    q3=t(as.matrix(q3))
    colnames(q3)=inp[inp!="Depth_m"]
    rownames(q3)=sort(unique(mdata[,out]))
    
    iq=t(as.matrix(iq))
    colnames(iq)=inp[inp!="Depth_m"]
    rownames(iq)=sort(unique(mdata[,out]))
    
    # Data cleaning
    
    removed=0
    idx=c()
    
    # Pre-filtering
    
    cat("\nPre-filtering\n")
    
    for(obj in 1:nrow(mdata)){
      class=as.character(mdata[obj,out])
      for(at in inp[inp!="Depth_m"]){
        if(mdata[obj,at]>q3[class,at]+1.5*iq[class,at]
           || mdata[obj,at]<q1[class,at]-1.5*iq[class,at]){
          if(length(idx)==0 || obj!=idx[length(idx)]){
            idx=append(idx,obj)
            #cat("Pre-filtered:",length(idx),"\n")
            #cat("Object:",obj,"\n\n")
          }
        }
      }
    }
    
    # Data frame of test data set
    
    data=as.data.frame(mdata)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    # Filtering
    
    cat("\nFiltering\n")
    
    filt=0
    
    for(obj in 1:length(idx)){
      fitTrain <- kknn(formula=form,
                       train=data[-idx[obj],],
                       test=data[idx[obj],],
                       k=1,
                       distance=2,
                       kernel=mode,
                       scale=FALSE)
      
      pred=fitTrain$fitted.values
      
      filt=filt+1
      
      # Remove object if it was misclassified
      
      if(pred!=data[idx[obj],out]){
        data=data[-idx[obj],]
        mdata=mdata[-idx[obj],]
        idx=idx-1
        removed=removed+1
        #cat("Filtered:",removed,"\n\n")
        #cat("Pre-filtered object:",filt,"\n")
      }
    }
    
    # Training data set as matrix
    
    data[,out]=as.numeric(as.character(data[,out]))
    mdata=as.matrix(data)
    
    # Initializing sets for balanced training set
    
    mdatab=mdata
    
    # Proportion check
    
    cat("\nProportion check\n\n")
    
    prop=c()
    
    for(j in sort(unique(mdatab[,out]))){
      prop=append(prop,nrow(mdatab[mdatab[,out]==j,]))
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    cat("\nBalancing\n\n")
    
    # Number of elements in the minority class
    
    minProp=min(prop)
    
    # Total number of elements by class
    
    nTot=max(1000,2*minProp)
    
    # Balancing
    
    for(j in sort(unique(mdatab[,out]))){
      mtrainClass=mdatab[mdatab[,out]==j,]
      numEl=nrow(mtrainClass)
      if(numEl>nTot){
        set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
        objIdx=sample(nrow(mtrainClass),numEl-nTot)
        mdatab=rbind(mdatab[mdatab[,out]!=j,],mtrainClass[-objIdx,])
      }
      else if(numEl<nTot){
        for(p in 1:(nTot-numEl)){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),length(inp)+1)
          obj=c()
          for(at in colnames(mdatab)){
            if(at==out){
              obj=append(obj,j)
            }else{
              obj=append(obj,mean(mtrainClass[objIdx,at]))
            }
          }
          mdatab=rbind(mdatab,obj)
        }
      }
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    # Modifying with one-to-c (canonic) encoding
    
    classZero=min(unique(mdata[,out]))
    nclass=max(unique(mdata[,out]))
    iniCols=ncol(mdata)
    for(j in classZero:nclass){
      mdata=cbind(mdata,matrix(0,nrow(mdata),1))
      colnames(mdata)[length(colnames(mdata))]=paste("c",as.character(j),sep="")
      mdatab=cbind(mdatab,matrix(0,nrow(mdatab),1))
      colnames(mdatab)[length(colnames(mdatab))]=paste("c",as.character(j),sep="")
    }
    for(j in 1:nrow(mdata)){
      mdata[j,iniCols+mdata[j,out]+1-classZero]=1
    }
    for(j in 1:nrow(mdatab)){
      mdatab[j,iniCols+mdatab[j,out]+1-classZero]=1
    }
    mdata=mdata[,colnames(mdata)!=out]
    mdatab=mdatab[,colnames(mdatab)!=out]
    iniCols=iniCols-1
    
    # Normalization of balanced training set
    
    cat("\nBalanced training set normalization\n\n")
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdatab[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdatab[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdatab)){
        mdatab[obj,inp[j]]=(mdatab[obj,inp[j]]-mini)/(maxi-mini)
      }
    }
    # New formula
    
    fout=colnames(mdata)[iniCols+1]
    
    for(j in (classZero+1):nclass){
      fout=paste(fout,colnames(mdata)[iniCols+j+1-classZero],sep="+")
    }
    
    form=paste(fout,as.character(form)[length(as.character(form))],sep="~")
    
    form=as.formula(form)
    
    # From matrix into dataframe
    
    data=as.data.frame(mdata)
    rownames(data)=NULL
    
    datab=as.data.frame(mdatab)
    rownames(datab)=NULL
    
    # Constructing the model
    
    it=mean(kval[,"iterations"])
    
    if(bm!=0){
      model = mlp(x=mdatab[,c(1:iniCols)],y=mdatab[,-c(1:iniCols)],size=c(bn,bm),maxit=it,outputActFunc="Act_Logistic")
    }else{
      model = mlp(x=mdatab[,c(1:iniCols)],y=mdatab[,-c(1:iniCols)],size=c(bn),maxit=it,outputActFunc="Act_Logistic")
    }
    
    # Saving weights matrix
    
    lowm[[length(lowm)+1]]=model$snnsObject$getCompleteWeightMatrix()
  }
}

# Initializing parameters
##############################################################################

# Selected data set

data=dataNet # Change it inside loop too

# Folds for the selected data set

folds=foldsNet

# Input features set

inputs=list(c("Qtn","Fr_p","U2"))

# Outputs

outputs=c("MSBTn")

# ANN application - Biased combination of 2016
##############################################################################

# For each output set

for(out in outputs){
  # For each input set
  
  for(inpCase in 1:length(inputs)){
    
    # Selecting input features
    
    inp=inputs[[inpCase]]
    
    # Atualizing data set
    
    data=dataNet
    
    # Eliminating other features from data
    
    datancol=ncol(data)
    idxr=c()
    
    for(i in 1:datancol){
      at=colnames(data)[i]
      if(length(inp[inp==at])==0 && at!=out){
        idxr=append(idxr,i)
      }
    }
    
    data=data[,-idxr]
    
    #10-fold cross-validation technique
    
    for(i in 1:10){
      
      # Defining formula
      
      form=paste(inp,collapse="+")
      form=as.formula(paste(append(out,form),collapse="~"))
      
      # Testing case
      
      cat("Testing case:",i,"\n\n")
      
      # Test data set as matrix
      
      mtest=as.matrix(data[folds[[i]],])
      
      # Validation data set as matrix
      
      mvalid=as.matrix(data[folds[[validFolds[i]]],])
      
      # Training data set as matrix
      
      mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
      
      # Removing Robertson's (1991) class 0
      
      if(out=="SBTn"){
        mtest=mtest[mtest[,out]!=0,]
        mvalid=mvalid[mvalid[,out]!=0,]
        mtrain=mtrain[mtrain[,out]!=0,]
      }
      
      # Normalization
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrain[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrain)){
          t=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
          mtrain[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mvalid)){
          t=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
          mvalid[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
        for(obj in 1:nrow(mtest)){
          t=(mtest[obj,inp[j]]-mini)/(maxi-mini)
          mtest[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
        }
      }
      
      # Statistical marks for pre-filtering
      
      q1=c()
      q3=c()
      
      for(class in sort(unique(mtrain[,out]))){
        auxq1=c()
        auxq3=c()
        for(at in inp[inp!="Depth_m"]){
          
          # First quartile
          
          auxq1=append(auxq1,quantile(mtrain[mtrain[,out]==class,at])[2])
          
          # Third quartile
          
          auxq3=append(auxq3,quantile(mtrain[mtrain[,out]==class,at])[4])
          
        }
        q1=cbind(q1,auxq1)
        q3=cbind(q3,auxq3)
      }
      
      
      # Interquartil interval
      
      iq=q3-q1
      
      # Formating
      
      q1=t(as.matrix(q1))
      colnames(q1)=inp[inp!="Depth_m"]
      rownames(q1)=sort(unique(mtrain[,out]))
      
      q3=t(as.matrix(q3))
      colnames(q3)=inp[inp!="Depth_m"]
      rownames(q3)=sort(unique(mtrain[,out]))
      
      iq=t(as.matrix(iq))
      colnames(iq)=inp[inp!="Depth_m"]
      rownames(iq)=sort(unique(mtrain[,out]))
      
      # Data cleaning
      
      removed=0
      idx=c()
      
      # Pre-filtering
      
      cat("\nPre-filtering\n")
      
      for(obj in 1:nrow(mtrain)){
        class=as.character(mtrain[obj,out])
        for(at in inp[inp!="Depth_m"]){
          if(mtrain[obj,at]>q3[class,at]+1.5*iq[class,at]
             || mtrain[obj,at]<q1[class,at]-1.5*iq[class,at]){
            if(length(idx)==0 || obj!=idx[length(idx)]){
              idx=append(idx,obj)
              #cat("Pre-filtered:",length(idx),"\n")
              #cat("Object:",obj,"\n\n")
            }
          }
        }
      }
      
      # Data frame of test data set
      
      test=as.data.frame(mtest)
      
      # Data frame of validation data set
      
      valid=as.data.frame(mvalid)
      
      # Data frame of training data set
      
      train=as.data.frame(mtrain)
      
      # Converting outputs of the data frames into factors
      
      test[,out]=as.factor(test[,out])
      valid[,out]=as.factor(valid[,out])
      train[,out]=as.factor(train[,out])
      
      # Filtering
      
      cat("\nFiltering\n")
      
      filt=0
      
      for(obj in 1:length(idx)){
        fitTrain <- kknn(formula=form,
                         train=train[-idx[obj],],
                         test=train[idx[obj],],
                         k=1,
                         distance=2,
                         kernel=mode,
                         scale=FALSE)
        
        pred=fitTrain$fitted.values
        
        filt=filt+1
        
        # Remove object if it was misclassified
        
        if(pred!=train[idx[obj],out]){
          train=train[-idx[obj],]
          mtrain=mtrain[-idx[obj],]
          idx=idx-1
          removed=removed+1
          #cat("Filtered:",removed,"\n\n")
          #cat("Pre-filtered object:",filt,"\n")
        }
      }
      
      # Training data set as matrix
      
      train[,out]=as.numeric(as.character(train[,out]))
      mtrain=as.matrix(train)
      
      # Initializing sets for balanced training set
      
      mtrainb=mtrain
      mtestb=mtest
      mvalidb=mvalid
      
      # Proportion check
      
      cat("\nProportion check\n\n")
      
      prop=c()
      
      for(j in sort(unique(mtrainb[,out]))){
        prop=append(prop,nrow(mtrainb[mtrainb[,out]==j,]))
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      cat("\nBalancing\n\n")
      
      # Number of elements in the minority class
      
      minProp=min(prop)
      
      # Total number of elements by class
      
      nTot=max(1000,2*minProp)
      
      # Balancing
      
      for(j in sort(unique(mtrainb[,out]))){
        mtrainClass=mtrainb[mtrainb[,out]==j,]
        numEl=nrow(mtrainClass)
        if(numEl>nTot){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),numEl-nTot)
          mtrainb=rbind(mtrainb[mtrainb[,out]!=j,],mtrainClass[-objIdx,])
        }
        else if(numEl<nTot){
          for(p in 1:(nTot-numEl)){
            set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
            objIdx=sample(nrow(mtrainClass),length(inp)+1)
            obj=c()
            for(at in colnames(mtrainb)){
              if(at==out){
                obj=append(obj,j)
              }else{
                obj=append(obj,mean(mtrainClass[objIdx,at]))
              }
            }
            mtrainb=rbind(mtrainb,obj)
          }
        }
        cat("Class", j, ":", nrow(mtrainb[mtrainb[,out]==j,]),"\n")
      }
      
      # Modifying with one-to-c (canonic) encoding
      
      classZero=min(unique(mtrain[,out]))
      nclass=max(unique(mtrain[,out]))
      iniCols=ncol(mtrain)
      for(j in classZero:nclass){
        mtrain=cbind(mtrain,matrix(0,nrow(mtrain),1))
        colnames(mtrain)[length(colnames(mtrain))]=paste("c",as.character(j),sep="")
        mvalid=cbind(mvalid,matrix(0,nrow(mvalid),1))
        colnames(mvalid)[length(colnames(mvalid))]=paste("c",as.character(j),sep="")
        mtest=cbind(mtest,matrix(0,nrow(mtest),1))
        colnames(mtest)[length(colnames(mtest))]=paste("c",as.character(j),sep="")
        mtrainb=cbind(mtrainb,matrix(0,nrow(mtrainb),1))
        colnames(mtrainb)[length(colnames(mtrainb))]=paste("c",as.character(j),sep="")
        mvalidb=cbind(mvalidb,matrix(0,nrow(mvalidb),1))
        colnames(mvalidb)[length(colnames(mvalidb))]=paste("c",as.character(j),sep="")
        mtestb=cbind(mtestb,matrix(0,nrow(mtestb),1))
        colnames(mtestb)[length(colnames(mtestb))]=paste("c",as.character(j),sep="")
      }
      for(j in 1:nrow(mtrain)){
        mtrain[j,iniCols+mtrain[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtest)){
        mtest[j,iniCols+mtest[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mvalid)){
        mvalid[j,iniCols+mvalid[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtrainb)){
        mtrainb[j,iniCols+mtrainb[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mtestb)){
        mtestb[j,iniCols+mtestb[j,out]+1-classZero]=1
      }
      for(j in 1:nrow(mvalidb)){
        mvalidb[j,iniCols+mvalidb[j,out]+1-classZero]=1
      }
      mtrain=mtrain[,colnames(mtrain)!=out]
      mtest=mtest[,colnames(mtest)!=out]
      mvalid=mvalid[,colnames(mvalid)!=out]
      mtrainb=mtrainb[,colnames(mtrainb)!=out]
      mtestb=mtestb[,colnames(mtestb)!=out]
      mvalidb=mvalidb[,colnames(mvalidb)!=out]
      iniCols=iniCols-1
      
      # # Normalization of unbalanced training set
      # 
      # cat("\nUnbalanced training set normalization\n\n")
      # 
      # minVal=c()
      # 
      # for(j in 1:length(inp)){
      #   minVal=cbind(minVal,min(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with minimum values
      # 
      # minVal=as.matrix(minVal)
      # colnames(minVal)=inp
      # 
      # maxVal=c()
      # 
      # for(j in 1:length(inp)){
      #   maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
      # }
      # 
      # # Data frame with maximum values
      # 
      # maxVal=as.matrix(maxVal)
      # colnames(maxVal)=inp
      # 
      # # Normalizing
      # 
      # for(j in 1:length(inp)){
      #   
      #   mini=minVal[j]
      #   maxi=maxVal[j]
      #   
      #   cat("Normalizing",inp[j],"\n")
      #   
      #   for(obj in 1:nrow(mtrain)){
      #     mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mvalid)){
      #     mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      #   for(obj in 1:nrow(mtest)){
      #     mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
      #   }
      # }
      
      # Normalization of balanced training set
      
      cat("\nBalanced training set normalization\n\n")
      
      minVal=c()
      
      for(j in 1:length(inp)){
        minVal=cbind(minVal,min(mtrainb[,inp[j]]))
      }
      
      # Data frame with minimum values
      
      minVal=as.matrix(minVal)
      colnames(minVal)=inp
      
      maxVal=c()
      
      for(j in 1:length(inp)){
        maxVal=cbind(maxVal,max(mtrainb[,inp[j]]))
      }
      
      # Data frame with maximum values
      
      maxVal=as.matrix(maxVal)
      colnames(maxVal)=inp
      
      # Normalizing
      
      for(j in 1:length(inp)){
        
        mini=minVal[j]
        maxi=maxVal[j]
        
        cat("Normalizing",inp[j],"\n")
        
        for(obj in 1:nrow(mtrainb)){
          mtrainb[obj,inp[j]]=(mtrainb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mvalidb)){
          mvalidb[obj,inp[j]]=(mvalidb[obj,inp[j]]-mini)/(maxi-mini)
        }
        for(obj in 1:nrow(mtestb)){
          mtestb[obj,inp[j]]=(mtestb[obj,inp[j]]-mini)/(maxi-mini)
        }
      }
      # New formula
      
      fout=colnames(mtrain)[iniCols+1]
      
      for(j in (classZero+1):nclass){
        fout=paste(fout,colnames(mtrain)[iniCols+j+1-classZero],sep="+")
      }
      
      form=paste(fout,as.character(form)[length(as.character(form))],sep="~")
      
      form=as.formula(form)
      
      # From matrix into dataframe
      
      train=as.data.frame(mtrain)
      rownames(train)=NULL
      valid=as.data.frame(mvalid)
      rownames(valid)=NULL
      test=as.data.frame(mtest)
      rownames(test)=NULL
      
      trainb=as.data.frame(mtrainb)
      rownames(trainb)=NULL
      validb=as.data.frame(mvalidb)
      rownames(validb)=NULL
      testb=as.data.frame(mtestb)
      rownames(testb)=NULL
      
      # # Pre-testing the balanced set
      # 
      # # Constructing the model
      # 
      # model = mlp(x=mtrainb[,c(1:iniCols)],y=mtrainb[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=200,outputActFunc="Act_Logistic")
      # 
      # # Predictions
      # 
      # predictions=predict(model,mvalidb[,1:iniCols])
      # preds=predictions
      # for(p in 1:nrow(preds)){
      #   for(q in 1:ncol(preds)){
      #     if(preds[p,q]==max(preds[p,])){
      #       preds[p,q]=1
      #     }else{
      #       preds[p,q]=0
      #     }
      #   }
      # }
      # 
      # # Calculating accuracy
      # 
      # mpb=0
      # 
      # for(j in classZero:nclass){
      #   mpb=mpb+sum(preds[preds[,j+1-classZero]==mvalidb[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalidb[,iniCols+j+1-classZero])
      # }
      # 
      # mpb=mpb/(nclass-classZero+1)
      # 
      # cat("\nBalanced training set pre-test accuracy:",mpb,"\n\n")
      # 
      # # Pre-testing the unbalanced set
      # 
      # # Constructing the model
      # 
      # model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=200,outputActFunc="Act_Logistic")
      # 
      # # Predictions
      # 
      # predictions=predict(model,mvalid[,1:iniCols])
      # preds=predictions
      # for(p in 1:nrow(preds)){
      #   for(q in 1:ncol(preds)){
      #     if(preds[p,q]==max(preds[p,])){
      #       preds[p,q]=1
      #     }else{
      #       preds[p,q]=0
      #     }
      #   }
      # }
      # 
      # # Calculating accuracy
      # 
      # mp=0
      # 
      # for(j in classZero:nclass){
      #   mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
      # }
      # 
      # mp=mp/(nclass-classZero+1)
      # 
      # cat("Unbalanced training set pre-test accuracy:",mp*100,"\n\n")
      # 
      # if(mpb>mp){
      #   mtrain=mtrainb
      #   mtest=mtestb
      #   mvalid=mvalidb
      #   cat("Using balanced set!\n\n")
      # }
      # else{
      #   cat("Using unbalanced set!\n\n")
      # }
      
      mtrain=mtrainb
      mtest=mtestb
      mvalid=mvalidb
      cat("Using balanced set!\n\n")
      
      # Determining the maximum number of iterations
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp=0
      
      # Initializing number of neurons on the first hidden layer
      
      it=200
      
      while(cont){
        
        cat("Training with ", it," iterations\n\n")
        
        # Constructing the model
        
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(nclass-classZero+1),maxit=it,outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalid[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        if(mp < prevmp){
          cont=0
          it=it-200
        }else{
          it=it+200
          prevmp=mp
        }
      }
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean precision
      
      prevmp1=0
      
      # Initializing number of neurons on the first hidden layer
      
      n=1#nclass-classZero+1
      
      # Initializing the best number of neurons
      
      nmax=1#nclass-classZero+1
      
      # Training
      
      while(cont){
        
        cat("Training for n =",n," and m =", 0, "\n")
        
        # Constructing the model
        
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n),maxit=it,outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalid[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        # if(mp < prevmp1){
        #   cont=0
        #   n=n-1
        # }else{
        #   n=n+1
        #   prevmp1=mp
        # }
        
        if(mp > prevmp1){
          prevmp1=mp
          nmax=n
        }
        
        if(n==2*(nclass-classZero+1)){
          cont=0
        }else{
          n=n+1
        }
      }
      
      n=nmax
      
      # Boolean indicating if the "while" loop must go on
      
      cont=1
      
      # Initializing a variable to keep the previous mean recall
      
      prevmp2=0
      
      # Initializing number of neurons on the second hidden layer
      
      m=1#nclass-classZero+1
      
      # Initializing the best number of neurons
      
      mmax=1#nclass-classZero+1
      
      # Training
      
      while(cont){
        
        cat("Training for n =",n," and m =", m, "\n")
        
        # Constructing the model
        
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n,m),maxit=it,hiddenActFunc="Act_Logistic",outputActFunc="Act_Logistic")
        
        # Predictions
        
        predictions=predict(model,mvalid[,1:iniCols])
        preds=predictions
        for(p in 1:nrow(preds)){
          for(q in 1:ncol(preds)){
            if(preds[p,q]==max(preds[p,])){
              preds[p,q]=1
            }else{
              preds[p,q]=0
            }
          }
        }
        
        # Calculating accuracy
        
        mp=0
        
        for(j in classZero:nclass){
          mp=mp+sum(preds[preds[,j+1-classZero]==mvalid[,iniCols+j+1-classZero],j+1-classZero])/sum(mvalid[,iniCols+j+1-classZero])
        }
        
        mp=mp/(nclass-classZero+1)
        
        cat("Accuracy:",mp*100,"%\n\n")
        
        # if(mp < prevmp2){
        #   cont=0
        #   m=m-1
        # }else{
        #   m=m+1
        #   prevmp2=mp
        # }
        
        if(mp > prevmp2){
          prevmp2=mp
          mmax=m
        }
        
        if(m==2*(nclass-classZero+1)){
          cont=0
        }else{
          m=m+1
        }
      }
      
      # Using the second hidden layer just if it improves the model
      
      if(prevmp2<=prevmp1){
        m=0
      }else{
        m=mmax
      }
      
      cat("Testing for n =",n,"and m =",m," with",it,"iterations\n")
      
      # Testing
      
      # Constructing the model
      
      if(m!=0){
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n,m),maxit=it,outputActFunc="Act_Logistic")
      }else{
        model = mlp(x=mtrain[,c(1:iniCols)],y=mtrain[,-c(1:iniCols)],size=c(n),maxit=it,outputActFunc="Act_Logistic")
      }
      
      # Predictions
      
      predictions=predict(model,mtest[,1:iniCols])
      preds=predictions
      for(p in 1:nrow(preds)){
        for(q in 1:ncol(preds)){
          if(preds[p,q]==max(preds[p,])){
            preds[p,q]=1
          }else{
            preds[p,q]=0
          }
        }
      }
      
      # Calculating accuracy
      
      mp=0
      
      for(j in classZero:nclass){
        mp=mp+sum(preds[preds[,j+1-classZero]==mtest[,iniCols+j+1-classZero],j+1-classZero])/sum(mtest[,iniCols+j+1-classZero])
      }
      
      mp=mp/(nclass-classZero+1)
      
      cat("Accuracy:",mp*100,"%\n\n")
      
      # Keeping "n" value for the ith testing case
      
      kval[i,1]=n
      
      # Keeping "m" value for the ith testing case
      
      kval[i,2]=m
      
      # Keeping number of iterations
      
      kval[i,3]=it
      
      # Keeping accuracy related to "k"
      
      kval[i,4]=mp*100
    }
    
    # Adding kval to the list lokval
    
    lokval[[length(lokval)+1]]=kval
    
    # Adding mean to lokvalm
    
    lokvalm[[length(lokvalm)+1]]=mean(kval[,"accuracy"])
    
    # Adding standard deviation to lokvalsd
    
    lokvalsd[[length(lokvalsd)+1]]=sd(kval[,"accuracy"])
    
    # Best "n"
    
    x=kval[,"n"]
    z=table(as.vector(x))
    bn=as.numeric(names(z)[z == max(z)])[1]
    lon[[length(lon)+1]]=bn
    
    # Best "m"
    
    x=kval[,"m"]
    z=table(as.vector(x))
    bm=as.numeric(names(z)[z == max(z)])[1]
    lom[[length(lom)+1]]=bm
    
    # Defining formula
    
    form=paste(inp,collapse="+")
    form=as.formula(paste(append(out,form),collapse="~"))
    
    # Data as matrix
    
    mdata=as.matrix(data)
    
    # Removing Robertson's (1991) class 0
    
    if(out=="SBTn"){
      mdata=mdata[mdata[,out]!=0,]
    }
    
    # Normalization
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdata[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdata[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdata)){
        t=(mdata[obj,inp[j]]-mini)/(maxi-mini)
        mdata[obj,inp[j]]=t#sign(t)*log10(1+(10^2-1)*abs(t))/2
      }
    }
    
    # Statistical marks for pre-filtering
    
    q1=c()
    q3=c()
    
    for(class in sort(unique(mdata[,out]))){
      auxq1=c()
      auxq3=c()
      for(at in inp[inp!="Depth_m"]){
        
        # First quartile
        
        auxq1=append(auxq1,quantile(mdata[mdata[,out]==class,at])[2])
        
        # Third quartile
        
        auxq3=append(auxq3,quantile(mdata[mdata[,out]==class,at])[4])
        
      }
      q1=cbind(q1,auxq1)
      q3=cbind(q3,auxq3)
    }
    
    
    # Interquartil interval
    
    iq=q3-q1
    
    # Formating
    
    q1=t(as.matrix(q1))
    colnames(q1)=inp[inp!="Depth_m"]
    rownames(q1)=sort(unique(mdata[,out]))
    
    q3=t(as.matrix(q3))
    colnames(q3)=inp[inp!="Depth_m"]
    rownames(q3)=sort(unique(mdata[,out]))
    
    iq=t(as.matrix(iq))
    colnames(iq)=inp[inp!="Depth_m"]
    rownames(iq)=sort(unique(mdata[,out]))
    
    # Data cleaning
    
    removed=0
    idx=c()
    
    # Pre-filtering
    
    cat("\nPre-filtering\n")
    
    for(obj in 1:nrow(mdata)){
      class=as.character(mdata[obj,out])
      for(at in inp[inp!="Depth_m"]){
        if(mdata[obj,at]>q3[class,at]+1.5*iq[class,at]
           || mdata[obj,at]<q1[class,at]-1.5*iq[class,at]){
          if(length(idx)==0 || obj!=idx[length(idx)]){
            idx=append(idx,obj)
            #cat("Pre-filtered:",length(idx),"\n")
            #cat("Object:",obj,"\n\n")
          }
        }
      }
    }
    
    # Data frame of test data set
    
    data=as.data.frame(mdata)
    
    # Converting outputs of the data frames into factors
    
    data[,out]=as.factor(data[,out])
    
    # Filtering
    
    cat("\nFiltering\n")
    
    filt=0
    
    for(obj in 1:length(idx)){
      fitTrain <- kknn(formula=form,
                       train=data[-idx[obj],],
                       test=data[idx[obj],],
                       k=1,
                       distance=2,
                       kernel=mode,
                       scale=FALSE)
      
      pred=fitTrain$fitted.values
      
      filt=filt+1
      
      # Remove object if it was misclassified
      
      if(pred!=data[idx[obj],out]){
        data=data[-idx[obj],]
        mdata=mdata[-idx[obj],]
        idx=idx-1
        removed=removed+1
        #cat("Filtered:",removed,"\n\n")
        #cat("Pre-filtered object:",filt,"\n")
      }
    }
    
    # Training data set as matrix
    
    data[,out]=as.numeric(as.character(data[,out]))
    mdata=as.matrix(data)
    
    # Initializing sets for balanced training set
    
    mdatab=mdata
    
    # Proportion check
    
    cat("\nProportion check\n\n")
    
    prop=c()
    
    for(j in sort(unique(mdatab[,out]))){
      prop=append(prop,nrow(mdatab[mdatab[,out]==j,]))
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    cat("\nBalancing\n\n")
    
    # Number of elements in the minority class
    
    minProp=min(prop)
    
    # Total number of elements by class
    
    nTot=max(1000,2*minProp)
    
    # Balancing
    
    for(j in sort(unique(mdatab[,out]))){
      mtrainClass=mdatab[mdatab[,out]==j,]
      numEl=nrow(mtrainClass)
      if(numEl>nTot){
        set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
        objIdx=sample(nrow(mtrainClass),numEl-nTot)
        mdatab=rbind(mdatab[mdatab[,out]!=j,],mtrainClass[-objIdx,])
      }
      else if(numEl<nTot){
        for(p in 1:(nTot-numEl)){
          set.seed( as.integer((as.double(Sys.time())*1000+Sys.getpid()) %% 2^31) )
          objIdx=sample(nrow(mtrainClass),length(inp)+1)
          obj=c()
          for(at in colnames(mdatab)){
            if(at==out){
              obj=append(obj,j)
            }else{
              obj=append(obj,mean(mtrainClass[objIdx,at]))
            }
          }
          mdatab=rbind(mdatab,obj)
        }
      }
      cat("Class", j, ":", nrow(mdatab[mdatab[,out]==j,]),"\n")
    }
    
    # Modifying with one-to-c (canonic) encoding
    
    classZero=min(unique(mdata[,out]))
    nclass=max(unique(mdata[,out]))
    iniCols=ncol(mdata)
    for(j in classZero:nclass){
      mdata=cbind(mdata,matrix(0,nrow(mdata),1))
      colnames(mdata)[length(colnames(mdata))]=paste("c",as.character(j),sep="")
      mdatab=cbind(mdatab,matrix(0,nrow(mdatab),1))
      colnames(mdatab)[length(colnames(mdatab))]=paste("c",as.character(j),sep="")
    }
    for(j in 1:nrow(mdata)){
      mdata[j,iniCols+mdata[j,out]+1-classZero]=1
    }
    for(j in 1:nrow(mdatab)){
      mdatab[j,iniCols+mdatab[j,out]+1-classZero]=1
    }
    mdata=mdata[,colnames(mdata)!=out]
    mdatab=mdatab[,colnames(mdatab)!=out]
    iniCols=iniCols-1
    
    # Normalization of balanced training set
    
    cat("\nBalanced training set normalization\n\n")
    
    minVal=c()
    
    for(j in 1:length(inp)){
      minVal=cbind(minVal,min(mdatab[,inp[j]]))
    }
    
    # Data frame with minimum values
    
    minVal=as.matrix(minVal)
    colnames(minVal)=inp
    
    maxVal=c()
    
    for(j in 1:length(inp)){
      maxVal=cbind(maxVal,max(mdatab[,inp[j]]))
    }
    
    # Data frame with maximum values
    
    maxVal=as.matrix(maxVal)
    colnames(maxVal)=inp
    
    # Normalizing
    
    for(j in 1:length(inp)){
      
      mini=minVal[j]
      maxi=maxVal[j]
      
      cat("Normalizing",inp[j],"\n")
      
      for(obj in 1:nrow(mdatab)){
        mdatab[obj,inp[j]]=(mdatab[obj,inp[j]]-mini)/(maxi-mini)
      }
    }
    # New formula
    
    fout=colnames(mdata)[iniCols+1]
    
    for(j in (classZero+1):nclass){
      fout=paste(fout,colnames(mdata)[iniCols+j+1-classZero],sep="+")
    }
    
    form=paste(fout,as.character(form)[length(as.character(form))],sep="~")
    
    form=as.formula(form)
    
    # From matrix into dataframe
    
    data=as.data.frame(mdata)
    rownames(data)=NULL
    
    datab=as.data.frame(mdatab)
    rownames(datab)=NULL
    
    # Constructing the model
    
    it=mean(kval[,"iterations"])
    
    if(bm!=0){
      model = mlp(x=mdatab[,c(1:iniCols)],y=mdatab[,-c(1:iniCols)],size=c(bn,bm),maxit=it,outputActFunc="Act_Logistic")
    }else{
      model = mlp(x=mdatab[,c(1:iniCols)],y=mdatab[,-c(1:iniCols)],size=c(bn),maxit=it,outputActFunc="Act_Logistic")
    }
    
    # Saving weights matrix
    
    lowm[[length(lowm)+1]]=model$snnsObject$getCompleteWeightMatrix()
  }
}
