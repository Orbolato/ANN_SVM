mat=1
n0=3
n1=6
n2=5
n3=4
w3=round(lowm[[mat]][(n0+n1+1):(n0+n1+n2),(n0+n1+n2+1):(n0+n1+n2+n3)],2)
w2=round(lowm[[mat]][(n0+1):(n1+n0),(n0+n1+1):(n0+n1+n2)],2)
w1=round(t(lowm[[mat]][1:n0,(n0+1):(n1+n0)]),2)

w=w3

for(i in 1:nrow(w)){
  for(j in 1:ncol(w)){
    cat(w[i,j])
    if(j==ncol(w)){
      cat(" \\\\\n")
    }else{
      cat(" & ")
    }
  }
}
