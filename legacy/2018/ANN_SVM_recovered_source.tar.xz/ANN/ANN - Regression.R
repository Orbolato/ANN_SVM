##############################################################################
#Reading .csv file and saving the data in a variable

path = file.path("C:","Users","ORBOLATO","Desktop","Mestrado","Dados","Alex", "Alex.csv")
dataNet = read.table(path, header = TRUE, sep = ",", stringsAsFactor = FALSE)

##############################################################################
# Package for 10-fold cross validation

library(caret)

# Creating folds for the database without geological age

foldsNet=createFolds(dataNet[,out],k=10,list=TRUE,returnTrain=FALSE)

##############################################################################
# Application

# Package for ML techniques

library(neuralnet)
library(nnet)

# Selected data set

data=dataNet # Change it inside loop too

folds=foldsNet

# Input attributes set

inp=c("a.b","h.mm","E.N.mm2","v")

# Outputs

out="nx.N.mm"

# Initializing matrix

kval=matrix(0,10,4)
colnames(kval)=c("n","m","RMSE","Correlation")

rn=c()

for(i in 1:10){
  rn=rbind(rn,as.character(i))
}

rownames(kval)=rn

##############################################################################
# Defining validation sets for each test stage without reposition

# Vector with the chosen folds in sequence

validFolds=c()

# Vector with the picking options

pick=1:10

for(j in 1:10){
  
  # Selecting test fold
  
  cat("Test fold:",j,"\n\n")
  
  # Setting seed for sampling
  
  set.seed(j*37)
  
  # Sampling a fold for validation
  
  if(j<10){
    
    # Choosing some unchosen fold
    
    f=sample(pick[pick!=j],1)
    
    # Excluding chosen fold from the picking options
    
    pick=pick[pick!=f]
    
    # Keeping the fold identification
    
    validFolds=append(validFolds,f)
    
    # Print the choice
    
    cat("-> Validation fold:",f,"\n\n")
    
  }else{
    
    # Choosing the only unchosen fold remaining
    
    f=pick[1]
    
    # Excluding the last fold from the picking options
    
    pick=pick[pick!=f]
    
    # Keeping the fold identification
    
    validFolds=append(validFolds,f)
    
    # Print the last fold
    
    cat("-> Validation fold:",f,"\n\n")
    
  }
}

# Show the chosen folds in sequence

show(validFolds)

##############################################################################
# Artificial Neural Networks

# Eliminating other attributes from data

datancol=ncol(data)
idxr=c()

for(i in 1:datancol){
  at=colnames(data)[i]
  if(length(inp[inp==at])==0 && at!=out){
    idxr=append(idxr,i)
  }
}

if(!is.null(idxr)){
  data=data[,-idxr]
}

# Defining formula

form=paste(inp,collapse="+")
form=as.formula(paste(append(out,form),collapse="~"))

#10-fold cross-validation technique

for(i in 1:1){
  
  # Testing case
  
  cat("Testing case:",i,"\n\n")
  
  # Test data set as matrix
  
  mtest=as.matrix(data[folds[[i]],])
  
  # Validation data set as matrix
  
  mvalid=as.matrix(data[folds[[validFolds[i]]],])
  
  # Training data set as matrix
  
  mtrain=as.matrix(data[-append(folds[[i]],folds[[validFolds[i]]]),])
  
  # Normalization
  
  minVal=c()
  
  for(j in 1:length(inp)){
    minVal=cbind(minVal,min(mtrain[,inp[j]]))
  }
  
  # Data frame with minimum values
  
  minVal=as.matrix(minVal)
  colnames(minVal)=inp
  
  maxVal=c()
  
  for(j in 1:length(inp)){
    maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
  }
  
  # Data frame with maximum values
  
  maxVal=as.matrix(maxVal)
  colnames(maxVal)=inp
  
  # Normalizing
  
  for(j in 1:length(inp)){
    
    mini=minVal[j]
    maxi=maxVal[j]
    
    cat("Normalizing",inp[j],"\n")
    
    for(obj in 1:nrow(mtrain)){
      mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
    }
    for(obj in 1:nrow(mvalid)){
      mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
    }
    for(obj in 1:nrow(mtest)){
      mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
    }
  }
  
  # Statistical marks for filtering
  
  q1=c()
  q3=c()

  for(at in inp){
    
    # First quartile
    
    q1=append(q1,quantile(mtrain[,at])[2])
    
    # Third quartile
    
    q3=append(q3,quantile(mtrain[,at])[4])
    
  }
  
  # Interquartil interval
  
  iq=q3-q1
  
  # Formating
  
  q1=t(as.matrix(q1))
  colnames(q1)=inp
  
  q3=t(as.matrix(q3))
  colnames(q3)=inp
  
  iq=t(as.matrix(iq))
  colnames(iq)=inp
  
  # Data cleaning
  
  removed=0
  idx=c()
  
  # Filtering
  
  cat("\nFiltering\n")
  
  for(obj in 1:nrow(mtrain)){
    for(at in inp){
      if(mtrain[obj,at]>q3[1,at]+1.5*iq[1,at] || mtrain[obj,at]<q1[1,at]-1.5*iq[1,at]){
        if(length(idx)==0 || obj!=idx[length(idx)]){
          idx=append(idx,obj)
          cat("Filtered:",length(idx),"\n")
          cat("Object:",obj,"\n\n")
        }
      }
    }
  }
  
  # Removing filtered objects
  
  if(!is.null(idx)){
    mtrain=mtrain[-idx,]
  }
  
  # Normalization
  
  cat("\nNormalization\n\n")
  
  minVal=c()
  
  for(j in 1:length(inp)){
    minVal=cbind(minVal,min(mtrain[,inp[j]]))
  }
  
  # Data frame with minimum values
  
  minVal=as.matrix(minVal)
  colnames(minVal)=inp
  
  maxVal=c()
  
  for(j in 1:length(inp)){
    maxVal=cbind(maxVal,max(mtrain[,inp[j]]))
  }
  
  # Data frame with maximum values
  
  maxVal=as.matrix(maxVal)
  colnames(maxVal)=inp
  
  # Normalizing
  
  for(j in 1:length(inp)){
    
    mini=minVal[j]
    maxi=maxVal[j]
    
    cat("Normalizing",inp[j],"\n")
    
    for(obj in 1:nrow(mtrain)){
      mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
    }
    for(obj in 1:nrow(mvalid)){
      mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
    }
    for(obj in 1:nrow(mtest)){
      mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
    }
  }
  
  mini=min(mtrain[,out])
  maxi=max(mtrain[,out])
  
  cat("Normalizing",out,"\n")
  
  for(obj in 1:nrow(mtrain)){
    mtrain[obj,inp[j]]=(mtrain[obj,inp[j]]-mini)/(maxi-mini)
  }
  for(obj in 1:nrow(mvalid)){
    mvalid[obj,inp[j]]=(mvalid[obj,inp[j]]-mini)/(maxi-mini)
  }
  for(obj in 1:nrow(mtest)){
    mtest[obj,inp[j]]=(mtest[obj,inp[j]]-mini)/(maxi-mini)
  }
  
  # From matrix into dataframe
  
  train=as.data.frame(mtrain)
  rownames(train)=NULL
  valid=as.data.frame(mvalid)
  rownames(valid)=NULL
  test=as.data.frame(mtest)
  rownames(test)=NULL
  
  # Boolean indicating if the "while" loop must go on
  
  cont=1
  
  # Initializing a variable to keep the previous mean precision
  
  prevrmse=10^6
  
  # Initializing number of neurons on the first hidden layer
  
  n=1#length(inp)
  
  while(cont){
    
    cat("Training for n =",n,"and m =", 0, "\n")
    
    # Training
    
    # Constructing the model
    
    model = neuralnet(formula=form,hidden=c(n),linear.output=F,data=train,threshold=1)
    
    # Model plotting
    
    #plot(model)
    
    # Predictions
    
    predictions=compute(model,mvalid[,colnames(mvalid)!=out])
    preds=predictions$net.result
    
    # Calculating accuracy (RMSE)
    
    RMSE=sqrt(sum((preds-mvalid[,out])^2)/nrow(mvalid))
    cat("RMSE:",RMSE,"%\n\n")
    
    if(RMSE<prevrmse){
      prevrmse=RMSE
      n=n+1
    }else{
      n=n-1
      cont=0
    }
  }
  
  # Boolean indicating if the "while" loop must go on
  
  cont=1
    
  # Initializing number of neurons on the second hidden layer
    
  m=1
  
  while(cont){
    
    cat("Training for n =",n,"and m =", m, "\n")
    
    # Training
    
    # Constructing the model
    
    model = neuralnet(formula=form,hidden=c(n,m),linear.output=F,data=mtrain,threshold=1)
    
    # Model plotting
    
    #plot(model)
    
    # Predictions
    
    predictions=compute(model,mvalid[,colnames(mvalid)!=out])
    preds=predictions$net.result
    
    # Calculating accuracy (RMSE)
    
    RMSE=sqrt(sum((preds-mvalid[,out])^2)/nrow(mvalid))
    cat("RMSE:",RMSE,"%\n\n")
    
    if(RMSE<prevrmse){
      prevrmse=RMSE
      m=m+1
    }else{
      m=m-1
      cont=0
    }
  }
  
  cat("Testing\n")
  
  # Testing
  
  # Constructing the model
  
  if(m!=0){
    model = neuralnet(formula=form,hidden=c(n,m),linear.output=F,data=mtrain,threshold=1)
  }else{
    model = neuralnet(formula=form,hidden=c(n),linear.output=F,data=mtrain,threshold=1)
  }
  
  # Model plotting
  
  plot(model)
  
  # Predictions
  
  predictions=compute(model,mvalid[,colnames(mvalid)!=out])
  preds=predictions$net.result
  
  # Calculating accuracy (RMSE)
  
  RMSE=sqrt(sum((preds-mvalid[,out])^2)/nrow(mvalid))
  
  cat("RMSE:",RMSE,"%, correlation:",cor(preds,mvalid[,out]),"\n\n")
  
  # Keeping "n" value for the ith testing case
  
  kval[i,1]=n
  
  # Keeping "m" value for the ith testing case
  
  kval[i,2]=m
  
  # Keeping RMSE
  
  kval[i,3]=RMSE
  
  # Keeping correlation
  
  kval[i,4]=cor(preds,mvalid[,out])
}
